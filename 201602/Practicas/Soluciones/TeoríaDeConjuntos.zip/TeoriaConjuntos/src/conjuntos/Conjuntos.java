package conjuntos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Conjuntos {

	private ArrayList<String> conjunto = new ArrayList<String>();

	public ArrayList<String> getConjunto() {
		return conjunto;
	}
	public void getValor(int pos){
		conjunto.get(pos);
	}
	public void borrarRepetidos(){
		Set<String> hs = new HashSet<>();
		hs.addAll(conjunto);
		conjunto.clear();
		conjunto.addAll(hs);
	}
}