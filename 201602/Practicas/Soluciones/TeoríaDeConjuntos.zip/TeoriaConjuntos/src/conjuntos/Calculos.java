package conjuntos;

public class Calculos {

	private Conjuntos conjuntoA = new Conjuntos();
	private Conjuntos conjuntoB = new Conjuntos();
	private Conjuntos conjuntoC = new Conjuntos();
	private Conjuntos conjuntoU = new Conjuntos();
	private Conjuntos conjuntoInter = new Conjuntos();
	private String StringA, StringB, StringC, StringU;

	public Calculos(String StringA, String StringB, String StringC, String StringU) {
		this.StringA = StringA;
		this.StringB = StringB;
		this.StringC = StringC;
		this.StringU = StringU;
	}

	public void generarArray() {
		recorrerString(conjuntoA, StringA);
		recorrerString(conjuntoB, StringB);
		recorrerString(conjuntoC, StringC);
		recorrerString(conjuntoU, StringU);
		generarUniversal();
	}

	private void generarUniversal() {
		conjuntoU.getConjunto().addAll(conjuntoA.getConjunto());
		conjuntoU.getConjunto().addAll(conjuntoB.getConjunto());
		conjuntoU.getConjunto().addAll(conjuntoC.getConjunto());
		conjuntoU.borrarRepetidos();

	}

	public String textoUniversal() {
		String conjunto = "";

		for (int i = 0; i < conjuntoU.getConjunto().size(); i++) {

			if (i < conjuntoU.getConjunto().size() - 1) {
				conjunto += conjuntoU.getConjunto().get(i) + ",";
			} else {
				conjunto += conjuntoU.getConjunto().get(i);
			}
		}
		return conjunto;
	}

	public void recorrerString(Conjuntos conjunto, String cadena) {

		for (int i = 0; i < cadena.length(); i++) {
			for (int j = 0; j < cadena.length(); j++) {
				if (cadena.substring(j, j + 1).equals(",")) {
					conjunto.getConjunto().add(cadena.substring(i, j));
					i = j + 1;
				} else if (j == cadena.length() - 1) {
					conjunto.getConjunto().add(cadena.substring(i, j + 1));
					i = j + 1;
				}
			}
		}
		conjunto.borrarRepetidos();
	}

	public String diferenciaSim�trica() {

		String a = "", b = "", c = "", d = "";
		a = diferenciaSim(this.conjuntoA, this.conjuntoB, a + b);
		b = diferenciaSim(this.conjuntoB, this.conjuntoA, a + b);

		Conjuntos conjunto = new Conjuntos();
		recorrerString(conjunto, a + b);

		c = diferenciaSim(conjunto, conjuntoC, a + b);
		d = diferenciaSim(conjuntoC, conjunto, c);

		return "<html>" + c + "<br>" + d;
	}

	private String diferenciaSim(Conjuntos conjuntoA, Conjuntos conjuntoB, String b) {
		boolean encuentra = false;
		String a = "";
		int contar = 0;
		for (int i = 0; i < conjuntoA.getConjunto().size(); i++) {
			for (int j = 0; j < conjuntoB.getConjunto().size(); j++) {

				if (conjuntoA.getConjunto().get(i).equals(conjuntoB.getConjunto().get(j))) {
					encuentra = true;
				}
			}
			if (!encuentra) {
				a += conjuntoA.getConjunto().get(i) + ",";
				contar++;
			}
			if (contar % 10 == 0 && contar > 0) {
				a += "<br>";
			}
			encuentra = false;
		}
		return a;
	}

	public String union() {
		String a = "<html>";
		Conjuntos conjunto = new Conjuntos();

		conjunto.getConjunto().addAll(conjuntoA.getConjunto());
		conjunto.getConjunto().addAll(conjuntoB.getConjunto());
		conjunto.getConjunto().addAll(conjuntoC.getConjunto());
		conjunto.borrarRepetidos();

		for (int i = 0; i < conjunto.getConjunto().size(); i++) {
			if (i < conjunto.getConjunto().size() - 1) {

				if (i % 10 == 0 && i > 0) {
					a += "<br>";
				}

				a += conjunto.getConjunto().get(i) + ",";
			} else {
				if (i % 10 == 0 && i > 0) {
					a += "\n";
				}
				a += conjunto.getConjunto().get(i);
			}
		}
		return a;
	}

	public String interseccion() {
		String a = "";
		for (int i = 0; i < conjuntoA.getConjunto().size(); i++) {
			for (int j = 0; j < conjuntoB.getConjunto().size(); j++) {
				for (int w = 0; w < conjuntoC.getConjunto().size(); w++) {
					if (conjuntoA.getConjunto().get(i).equals(conjuntoB.getConjunto().get(j))) {
						if (conjuntoA.getConjunto().get(i).equals(conjuntoC.getConjunto().get(w))) {
							a += conjuntoA.getConjunto().get(i) + ",";
						}
					}
				}
			}
		}
		return a;
	}
	
	public String generarConjuntos(int opcion){
		String a = "";
		if(opcion == 0){
			//Conjunto A
			a = generarConjuntos(conjuntoA, conjuntoInter);
		}else if(opcion == 1){
			a = generarConjuntos(conjuntoB, conjuntoInter);
		}else if(opcion == 2){
			a = generarConjuntos(conjuntoC, conjuntoInter);
		}else if(opcion == 3){
			a = StringU;
		}
		return a;
	}
	
	private String generarConjuntos(Conjuntos conjuntoA, Conjuntos conjuntoB){
		String a = "";
		boolean encontro = false;
		for (int i = 0; i < conjuntoA.getConjunto().size(); i++) {
			for (int j = 0; j < conjuntoB.getConjunto().size(); j++) {
				if(conjuntoA.getConjunto().get(i).equals(conjuntoB.getConjunto().get(j))){
					encontro = true;
				}
			}
			if(!encontro){
				a += conjuntoA.getConjunto().get(i);
			}
			encontro = false;
		}
		return a;
	}
	
	public String generarInterseccion(int opcion){
		String a = "";
		String b = interseccion();
		Conjuntos conjunto = new Conjuntos();
		
		recorrerString(conjunto, b);
		
		if(opcion == 0){
			a = interseccion();
			recorrerString(conjuntoInter, a);
		}else if(opcion == 1){		
			a = interseccion(conjuntoA, conjuntoB,conjunto);
			recorrerString(conjuntoInter, a);
		}else if(opcion == 2){
			a = interseccion(conjuntoB, conjuntoC,conjunto);
			recorrerString(conjuntoInter, a);
		}else if(opcion == 3){
			a = interseccion(conjuntoA, conjuntoC,conjunto);
			recorrerString(conjuntoInter, a);
		}
 		return a;
	}
	
	private String interseccion(Conjuntos conjuntoA, Conjuntos conjuntoB, Conjuntos conjuntoC) {

		String a = "";
		Conjuntos conjunto = new Conjuntos();
		boolean esta = false;
		for (int i = 0; i < conjuntoA.getConjunto().size(); i++) {
			for (int j = 0; j < conjuntoB.getConjunto().size(); j++) {
				if (conjuntoA.getConjunto().get(i).equals(conjuntoB.getConjunto().get(j))) {
					esta = true;
				}
			}
			if(esta){
				a += conjuntoA.getConjunto().get(i) + ",";
			}
			esta = false;
		}
		recorrerString(conjunto, a);
		a  = "";
		for (int i = 0; i < conjunto.getConjunto().size(); i++) {
			for (int j = 0; j < conjuntoC.getConjunto().size(); j++) {
				if (conjunto.getConjunto().get(i).equals(conjuntoC.getConjunto().get(j))) {
					esta = true;
				}				
			}
			if(!esta){
				a += conjunto.getConjunto().get(i) + ",";
			}
			esta = false;
		}
		
		
		return a;
	}

	public String rara(){
		
		String a = generarInterseccion(1);
		a += generarConjuntos(0);
		return a;
	}
	public void imprimirArreglos(Conjuntos conjunto) {
		for (int i = 0; i < conjunto.getConjunto().size(); i++) {
			System.out.println("" + conjunto.getConjunto().get(i));
		}
	}
	
	public String operacionRara2(){
		String a = "";
		//a += generarInterseccion(0);
		a += generarInterseccion(1);
		a += generarInterseccion(2);
		a += generarInterseccion(3);
		a += generarConjuntos(3);
		
		return a;
	}
	
	public String operacionRara3(){
		String a;
		a = generarConjuntos(0)+",";
		a += generarConjuntos(3)+",";
		a += generarInterseccion(1);
		
		return a;
	}
}