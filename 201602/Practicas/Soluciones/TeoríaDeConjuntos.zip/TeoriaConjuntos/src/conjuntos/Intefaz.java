package conjuntos;

import java.applet.Applet;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JTextField;

import org.eclipse.swt.internal.win32.TBBUTTON;

import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Panel;
import javax.swing.SwingConstants;

public class Intefaz extends Applet{

	private static final long serialVersionUID = 1L;

	Calculos calculos;

	ImageIcon thisImage = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/Vac�os.png");

	private JFrame frame;
	private JTextField TF_CojuntoA;
	private JTextField TF_CojuntoB;
	private JTextField TF_CojuntoC;
	private JLabel lblConjuntoC;
	private JLabel lblConjuntoU;
	private JTextField TF_CojuntoU;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Intefaz window = new Intefaz();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the application.
	 */
	public Intefaz() {
		initialize();
		
	}

	private void inicializarConjuntos(){
		calculos = new Calculos(TF_CojuntoA.getText(),TF_CojuntoB.getText(),TF_CojuntoC.getText(),TF_CojuntoU.getText());
	}	
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 580, 345);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		TF_CojuntoA = new JTextField();
		TF_CojuntoA.setBounds(80, 14, 474, 20);
		frame.getContentPane().add(TF_CojuntoA);
		TF_CojuntoA.setColumns(10);
		
		JLabel lblConjuntoA = new JLabel("Conjunto A:");
		lblConjuntoA.setBounds(10, 17, 72, 14);
		frame.getContentPane().add(lblConjuntoA);
		
		JLabel lblConjuntoB = new JLabel("Conjunto B:");
		lblConjuntoB.setBounds(10, 48, 72, 14);
		frame.getContentPane().add(lblConjuntoB);
		
		lblConjuntoC = new JLabel("Conjunto C:");
		lblConjuntoC.setBounds(10, 77, 72, 14);
		frame.getContentPane().add(lblConjuntoC);
		
		lblConjuntoU = new JLabel("Conjunto U:");
		lblConjuntoU.setBounds(10, 108, 72, 14);
		frame.getContentPane().add(lblConjuntoU);
		
		TF_CojuntoB = new JTextField();
		TF_CojuntoB.setColumns(10);
		TF_CojuntoB.setBounds(80, 45, 474, 20);
		frame.getContentPane().add(TF_CojuntoB);
		
		TF_CojuntoC = new JTextField();
		TF_CojuntoC.setColumns(10);
		TF_CojuntoC.setBounds(80, 74, 474, 20);
		frame.getContentPane().add(TF_CojuntoC);
		
		TF_CojuntoU = new JTextField();
		TF_CojuntoU.setColumns(10);
		TF_CojuntoU.setBounds(80, 105, 474, 20);
		frame.getContentPane().add(TF_CojuntoU);
		
		JLabel lblconjuntoA = new JLabel("A");
		lblconjuntoA.setBounds(226, 156, 46, 46);
		frame.getContentPane().add(lblconjuntoA);
		
		JLabel lblconjuntoB = new JLabel("B");
		lblconjuntoB.setBounds(306, 146, 46, 42);
		frame.getContentPane().add(lblconjuntoB);
		
		JLabel lblconjuntoC = new JLabel("C");
		lblconjuntoC.setBounds(258, 225, 64, 46);
		frame.getContentPane().add(lblconjuntoC);
		
		JLabel lblinterAC = new JLabel("");
		lblinterAC.setBounds(252, 206, 32, 14);
		frame.getContentPane().add(lblinterAC);
		
		JLabel lblinterBC = new JLabel("");
		lblinterBC.setBounds(300, 199, 22, 30);
		frame.getContentPane().add(lblinterBC);
	    
		JLabel lblResultados = new JLabel("");
		lblResultados.setHorizontalAlignment(SwingConstants.CENTER);
		lblResultados.setBounds(10, 250, 122, 59);
		frame.getContentPane().add(lblResultados);
		
		JLabel lblResultado = new JLabel("Resultado:");
		lblResultado.setBounds(10, 257, 72, 14);
		frame.getContentPane().add(lblResultado);
		
		JLabel lblinterABC = new JLabel("");
		lblinterABC.setBounds(282, 188, 22, 20);
		frame.getContentPane().add(lblinterABC);
		
		JLabel lblinterAB = new JLabel("");
		lblinterAB.setBounds(276, 166, 28, 20);
		frame.getContentPane().add(lblinterAB);
		
		JLabel lblU = new JLabel("U");
		lblU.setBounds(158, 241, 90, 30);
		frame.getContentPane().add(lblU);
		
		JLabel lblHola = new JLabel("");
		lblHola.setBounds(142, 135, 295, 147);
		frame.getContentPane().add(lblHola);
		lblHola.setForeground(Color.WHITE);
		lblHola.setHorizontalAlignment(SwingConstants.CENTER);
		lblHola.setBackground(Color.WHITE);
		lblHola.setIcon(new ImageIcon("C:\\Users\\Sllr\\workspace\\TeoriaConjuntos\\src\\conjuntos\\Vac\u00EDos.png"));
		JButton btn_Union = new JButton("A U B U C");
		btn_Union.setEnabled(false);
		btn_Union.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ImageIcon Imagen = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/Union.png");
				lblHola.setIcon(Imagen);
				lblResultados.setText(calculos.union());
			}
		});

		btn_Union.setBounds(10, 156, 138, 23);
		frame.getContentPane().add(btn_Union);
		
		JButton btn_Interseccion = new JButton("A \u2229 B \u2229 C");
		btn_Interseccion.setEnabled(false);
		btn_Interseccion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon Imagen = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/Intersecci�n.png");
				lblHola.setIcon(Imagen);
				lblResultados.setText(calculos.interseccion());
			}
		});
		btn_Interseccion.setBounds(10, 179, 138, 23);
		frame.getContentPane().add(btn_Interseccion);
		
		JButton btnDifSime = new JButton("(A \u0394 B) \u0394 C");
		btnDifSime.setEnabled(false);
		btnDifSime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ImageIcon Imagen = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/DiferenciaSim�trica.png");
				lblHola.setIcon(Imagen);
				
				lblResultados.setText(calculos.diferenciaSim�trica());
			}
		});
		
		JButton btnRaro = new JButton("(A U B) \u2229 ( A \u0394 C )");
		btnRaro.setEnabled(false);
		btnRaro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ImageIcon Imagen = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/Raro.png");
				lblHola.setIcon(Imagen);
				
				lblResultados.setText(calculos.rara());
				
			}
		});
		btnRaro.setBounds(10, 225, 138, 23);
		frame.getContentPane().add(btnRaro);
		
		
		btnDifSime.setBounds(10, 202, 138, 23);
		frame.getContentPane().add(btnDifSime);
		
		JButton btnRara2 = new JButton("(B \u0394 C) \u0394 A\u2019");
		btnRara2.setEnabled(false);
		btnRara2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ImageIcon Imagen = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/Rara2.png");
				lblHola.setIcon(Imagen);
				lblResultados.setText(calculos.operacionRara2());
				
			}
		});
		btnRara2.setBounds(432, 133, 122, 23);
		frame.getContentPane().add(btnRara2);
		
		JButton btn_Rara3 = new JButton("(B\u2013A)\u2019\u2229C\u2019");
		btn_Rara3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon Imagen = new ImageIcon("C:/Users/Sllr/workspace/TeoriaConjuntos/src/conjuntos/Rara3.png");
				lblHola.setIcon(Imagen);
				lblResultados.setText(calculos.operacionRara3());	
			}
		});
		btn_Rara3.setEnabled(false);
		btn_Rara3.setBounds(432, 156, 122, 23);
		frame.getContentPane().add(btn_Rara3);
		
		
		JButton btnGenerar = new JButton("Generar U");
		btnGenerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//calculos = new Calculos(TF_CojuntoA.getText(),TF_CojuntoB.getText(),TF_CojuntoC.getText(),TF_CojuntoU.getText());
				inicializarConjuntos();
				btn_Union.setEnabled(true);
				btn_Interseccion.setEnabled(true);
				btnDifSime.setEnabled(true);
				btnRaro.setEnabled(true);
				btnRara2.setEnabled(true);
				btn_Rara3.setEnabled(true);
				calculos.generarArray();
				//Intersecciones
				lblinterABC.setText(calculos.generarInterseccion(0));
				lblinterAB.setText(calculos.generarInterseccion(1));
				lblinterBC.setText(calculos.generarInterseccion(2));
				lblinterAC.setText(calculos.generarInterseccion(3));
				
				//Conjuntos
				lblconjuntoA.setText(calculos.generarConjuntos(0));
				lblconjuntoB.setText(calculos.generarConjuntos(1));
				lblconjuntoC.setText(calculos.generarConjuntos(2));
				lblU.setText(calculos.generarConjuntos(3));
				
				TF_CojuntoU.setText(calculos.textoUniversal());
				
				
			}
		});
		btnGenerar.setBounds(10, 133, 138, 23);
		frame.getContentPane().add(btnGenerar);
		


		

		

		

		


	}
}
